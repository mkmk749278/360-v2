
# PR2: Optimize Scanner for Top-50 Only

## Objective
Scan only top-50 futures pairs and feed active trade channel.

## Steps
1. Modify `scanner.py` loop to iterate only over top-50 pairs.
2. Remove processing of all other pairs (spot and non-top futures).
3. Asyncify scan loop for faster cycle (~2-5s expected).
4. Update suppression / volatile checks to only apply to top-50.
