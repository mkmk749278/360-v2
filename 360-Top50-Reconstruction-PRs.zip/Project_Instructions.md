
# 360 Main Engine Top-50 Reconstruction Instructions

## Overview
This PR reconstructs the engine to **focus only on top-50 futures pairs** for performance, low latency, and active trade reliability.

## Steps to Apply
1. Apply PR1 → top-50 pair manager implementation.
2. Apply PR2 → optimize scanner for top-50 only.
3. Apply PR3 → adjust AI pipeline to top-50 pairs only.
4. Apply PR4 → WS manager updates to top-50 streams.
5. Apply PR5 → optimize telemetry and logging.
6. Apply PR6 → VPS deployment for optimized engine.
7. Test active trade channel for latency, API weight, and real-time signal execution.
8. Ensure no portfolio or non-top-50 pairs are processed.
