
# PR1: Implement Dynamic Top-50 Futures Pair Manager

## Objective
Restrict engine to **top-50 futures pairs** by liquidity/volume or AI score.

## Steps
1. Implement `pair_manager.py` with:
   - Dynamic ranking of futures pairs.
   - Minimum update interval (e.g., 60-120s).
   - Only maintain top-50 pairs for scanning.
2. Provide API for scanner/AI to fetch only top-50 pairs.
3. Remove any logic that adds spot or low-volume futures.
