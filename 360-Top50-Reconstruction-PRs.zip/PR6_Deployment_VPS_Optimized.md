
# PR6: VPS Deployment Optimized for Top-50

## Objective
Deploy optimized top-50 engine on VPS efficiently.

## Steps
1. Install Python 3.10+, required packages (ccxt, asyncio, websockets, pandas).
2. Set environment variables for Binance API keys.
3. Deploy as systemd service or cron job.
4. Ensure dynamic top-50 updates are applied and logs rotate.
5. Verify API weight usage stays below limits (~1200/min).
