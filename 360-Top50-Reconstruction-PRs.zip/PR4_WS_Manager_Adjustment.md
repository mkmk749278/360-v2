
# PR4: WebSocket Manager Adjustment

## Objective
Reduce WS streams to top-50 pairs only.

## Steps
1. Only open streams for top-50 futures + critical pairs.
2. Remove spot streams entirely.
3. Ensure dynamic update of WS when top-50 changes.
4. Monitor WS health, reconnect lost streams dynamically.
