
# PR3: AI Pipeline Adjustment for Top-50

## Objective
Run predictive AI only on top-50 pairs for performance improvement.

## Steps
1. Update AI inference module to filter non-top-50 pairs.
2. GEM / multi-feature checks restricted to top-50.
3. Remove legacy loops processing all pairs.
