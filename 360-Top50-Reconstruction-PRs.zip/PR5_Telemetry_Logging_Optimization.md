
# PR5: Telemetry & Logging Optimization

## Objective
Reduce logging/telemetry overhead for improved latency.

## Steps
1. Log only top-50 active pairs and active trades.
2. Remove logs for non-top-50 pairs and portfolio signals.
3. Track scan latency, API usage, CPU/memory only for active trades.
